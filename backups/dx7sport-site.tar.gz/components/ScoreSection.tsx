'use client';

import React, { useState } from 'react';
import { SportsEvent } from '@/lib/pipeline/sportsdb';
import MatchDetailModal from './MatchDetailModal';

interface ScoreSectionProps {
  scores: SportsEvent[];
  title?: string;
  isPage?: boolean;
}

export function ScoreSection({ scores, title = "نتائج الدوريات الكبرى", isPage = false }: ScoreSectionProps) {
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);

  if (!scores || scores.length === 0) return null;

  const LEAGUE_NAME_AR: Record<string, string> = {
    'English Premier League': 'الدوري الإنجليزي الممتاز',
    'Spanish La Liga': 'الدوري الإسباني',
    'Italian Serie A': 'الدوري الإيطالي',
    'German Bundesliga': 'الدوري الألماني',
    'French Ligue 1': 'الدوري الفرنسي',
    'UEFA Champions League': 'دوري أبطال أوروبا',
    'UEFA Europa League': 'الدوري الأوروبي',
    'UEFA Conference League': 'دوري المؤتمر الأوروبي',
    'Saudi-Arabian Pro League': 'الدوري السعودي',
    'Saudi Pro League': 'الدوري السعودي',
    'Major League Soccer': 'الدوري الأمريكي'
  };

  // Group scores by league & FILTER Israeli league (Hard exclusion)
  const groupedScores = scores
    .filter(event => 
      event.idLeague !== '4344' && 
      !event.strLeague?.toLowerCase().includes('israel') &&
      !event.strHomeTeam?.toLowerCase().includes('maccabi') && // Extra safety for common Israeli club names
      !event.strAwayTeam?.toLowerCase().includes('maccabi') &&
      !event.strHomeTeam?.toLowerCase().includes('hapoel') &&
      !event.strAwayTeam?.toLowerCase().includes('hapoel')
    )
    .reduce((acc, event) => {
      const league = LEAGUE_NAME_AR[event.strLeague] || event.strLeague;
      if (!acc[league]) acc[league] = [];
      acc[league].push(event);
      return acc;
    }, {} as Record<string, SportsEvent[]>);

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('ar-EG', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false,
      numberingSystem: 'latn'
    });
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('ar-EG', { 
      day: 'numeric', 
      month: 'short',
      numberingSystem: 'latn'
    });
  };

  return (
    <>
      <section className={`py-12 ${isPage ? '' : 'border-b border-zinc-900 bg-black'} overflow-hidden`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-2 h-2 bg-lime rounded-full animate-pulse shadow-[0_0_10px_rgba(179,212,0,0.8)]" />
            <h2 className="text-xs font-black text-white uppercase tracking-[0.4em]">{title}</h2>
          </div>
          {!isPage && (
            <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">تحديث مباشر</div>
          )}
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col gap-16">
          {Object.entries(groupedScores).map(([league, leagueEvents]) => (
            <div key={league} className="flex flex-col gap-8">
              <div className="flex items-center gap-4">
                 <div className="flex items-center gap-4 bg-zinc-950/50 pr-6 pl-4 py-2 border border-zinc-900 rounded-sm">
                   {leagueEvents[0]?.strLeagueBadge && (
                     <img src={leagueEvents[0].strLeagueBadge} alt="" className="w-10 h-10 object-contain drop-shadow-[0_0_10px_rgba(179,212,0,0.2)]" />
                   )}
                   <h3 className="text-sm font-black text-lime uppercase tracking-widest">
                     {league}
                   </h3>
                 </div>
                 <div className="h-px flex-1 bg-zinc-900" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {leagueEvents.map((event) => (
                  <ScoreCard 
                    key={event.idEvent} 
                    event={event} 
                    formatTime={formatTime} 
                    formatDate={formatDate}
                    onClick={() => setSelectedEventId(event.idEvent)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <MatchDetailModal 
        eventId={selectedEventId} 
        onClose={() => setSelectedEventId(null)} 
      />
    </>
  );
}

function ScoreCard({ event, formatTime, formatDate, onClick }: { event: SportsEvent, formatTime: any, formatDate: any, onClick: () => void }) {
  // IMPROVED LIVE LOGIC: Be more specific about what counts as LIVE
  const status = event.strStatus?.toUpperCase() || '';
  const now = new Date();
  const startTime = new Date(event.strTimestamp);
  const diffMinutes = (now.getTime() - startTime.getTime()) / (1000 * 60);
  
  // A game is only live if it has a live status AND is within a reasonable timeframe (started within 2.5 hours)
  const isLive = (['1H', '2H', 'HT', 'LIVE', 'P2', 'P1'].includes(status) || 
                  (status.includes("'") && !status.includes("FT"))) &&
                  diffMinutes >= -5 && diffMinutes < 240; // Max 240 mins for live games

  // If the game started long ago but isn't explicitly live, it's finished
  const isFinished = ['MATCH FINISHED', 'FT', 'AET', 'PEN', 'P'].includes(status) || (diffMinutes >= 240 && !isLive);
  const isPostponed = ['PST', 'CANCL', 'ABD'].includes(status);

  return (
    <div 
      onClick={onClick}
      className="bg-zinc-950 border border-zinc-900 p-6 hover:border-lime/30 transition-all group/card relative overflow-hidden cursor-pointer active:scale-95 duration-200"
    >
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-lime/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
      
      <div className="flex flex-col gap-6 relative z-10">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {event.strHomeTeamBadge && (
                <img src={event.strHomeTeamBadge} alt="" className="w-10 h-10 object-contain drop-shadow-[0_0_8px_rgba(255,255,255,0.1)]" />
              )}
              <span className="text-base font-black text-white truncate max-w-[160px] uppercase italic tracking-normal px-1">
                {event.strHomeTeam}
              </span>
            </div>
            <span className="text-4xl font-black italic text-lime leading-none dxt-numeral">
              {event.intHomeScore || '0'}
            </span>
          </div>
          
          <div className="h-px w-full bg-zinc-900/50" />

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {event.strAwayTeamBadge && (
                <img src={event.strAwayTeamBadge} alt="" className="w-10 h-10 object-contain drop-shadow-[0_0_8px_rgba(255,255,255,0.1)]" />
              )}
              <span className="text-base font-black text-white truncate max-w-[160px] uppercase italic tracking-normal px-1">
                {event.strAwayTeam}
              </span>
            </div>
            <span className="text-4xl font-black italic text-lime leading-none dxt-numeral">
              {event.intAwayScore || '0'}
            </span>
          </div>
        </div>

        <div className="pt-4 border-t border-zinc-900 flex items-center justify-between">
          <div className="flex items-center gap-2">
             {isLive ? (
               <div className="flex items-center gap-2 px-2 py-0.5 bg-red-500/10 border border-red-500/20 rounded">
                 <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping" />
                 <span className="text-[9px] font-black text-red-500 uppercase tracking-tighter">Live {status.includes("'") ? status : ''}</span>
               </div>
             ) : (
               <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">
                 {isFinished ? 'منتهية' : isPostponed ? 'مؤجلة' : 'قادمة'}
               </span>
             )}
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-black text-white/40 tracking-widest dxt-numeral">
              {formatDate(event.strTimestamp)} | {formatTime(event.strTimestamp)} غرينتش
            </span>
            <span className="text-[8px] font-black text-lime uppercase tracking-widest mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
              عرض التفاصيل ←
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
